from django.contrib import admin
from .models import Actor

admin.site.register(Actor)

# Register your models here.
