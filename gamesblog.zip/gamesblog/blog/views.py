from django.shortcuts import render
from django.http import HttpResponse

from .models import Actor


def index(request):
	actors = Actor.objects.all()
	
	return render(request, 'index.html',  {'actors': actors} )
# Create your views here.
