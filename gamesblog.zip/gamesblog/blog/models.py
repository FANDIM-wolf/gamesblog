from django.db import models
from datetime import date


class Actor(models.Model):
	name = models.CharField("Name", max_length=100)
	date = models.PositiveSmallIntegerField("date",default=0)
	description = models.TextField("description")
	image = models.ImageField("Image", upload_to="games/",blank=True,null=True)

	#def __str__(self):
		#return self.name
# Create your models here.
